import React from 'react';
import { BrowserRouter as Router, Routes, Route, useNavigate } from 'react-router-dom';
import Welcome from './components/Welcome';
import Dashboard from './components/Dashboard';
import Quiz from './components/Quiz';
import Tutorial from './components/Tutorial';
import ChatRoom from './components/ChatRoom/ChatRoom';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<WelcomeWrapper />} />
        <Route path="/dashboard" element={<DashboardWrapper />} />
        <Route path="/quiz" element={<Quiz />} />
        <Route path="/tutorial" element={<TutorialWrapper />} />
        <Route path="/chatroom" element={<ChatRoom />} />
      </Routes>
    </Router>
  );
}

// Wrappers to handle navigation inside components using `useNavigate`
const WelcomeWrapper = () => {
  const navigate = useNavigate();
  return <Welcome onPlay={() => navigate('/dashboard')} />;
};

const DashboardWrapper = () => {
  const navigate = useNavigate();
  return (
    <Dashboard
      onStartQuiz={() => navigate('/quiz')}
      onGoToTutorial={() => navigate('/tutorial')}
      onBack={() => navigate('/')}
    />
  );
};

const TutorialWrapper = () => {
  const navigate = useNavigate();
  return <Tutorial onBack={() => navigate('/dashboard')} />;
};

export default App;

import React, { useState, useEffect } from 'react';
import io from 'socket.io-client';
import './ChatRoom.css';

const socket = io('http://localhost:5000');

const ChatRoom = () => {
  const [username, setUsername] = useState('');
  const [isUsernameSet, setIsUsernameSet] = useState(false);
  const [message, setMessage] = useState('');
  const [chat, setChat] = useState([]);

  // Send message to the server
  const sendMessage = () => {
    if (message.trim()) {
      const data = {
        username,
        message,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      socket.emit('chatMessage', data);  // Emit send_message event
      setMessage('');  // Clear input field
    }
  };

  // Receive messages from server and update chat
  useEffect(() => {
    socket.on('receive_message', (data) => {
      console.log('Received message:', data);  
      setChat((prev) => [...prev, data]);  // Update chat state
    });

    return () => {
      socket.off('receive_message');
    };
  }, []);

  if (!isUsernameSet) {
    return (
      <div className="username-bg">
        <div className="chat-container username-screen">
          <h2>👤 Enter your name</h2>
          <input
            type="text"
            placeholder="Your name"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && username && setIsUsernameSet(true)}
          />
          <button onClick={() => username && setIsUsernameSet(true)}>Start Chat</button>
        </div>
      </div>
    );
  }

  return (
    <div className="center-screen">
    <div className="chat-container">
      <h2>💬 React Chatroom</h2>
      <div className="chat-box">
        {chat.map((msg, index) => (
          <div
            key={index}
            className={`chat-msg ${msg.username === username ? 'self' : 'other'}`}
          >
            <div className="chat-meta">
              <strong>{msg.username}</strong> <span>{msg.time}</span>
            </div>
            <div>{msg.message}</div>
          </div>
        ))}
      </div>
      <div className="chat-input">
        <input
          type="text"
          placeholder="Type message..."
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && sendMessage()}
        />
        <button onClick={sendMessage}>Send</button>
      </div>
    </div>
    </div>
  );
};

export default ChatRoom;

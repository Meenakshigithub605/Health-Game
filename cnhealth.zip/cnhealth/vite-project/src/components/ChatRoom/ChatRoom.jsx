import React, { useState, useEffect, useRef } from 'react';
import io from 'socket.io-client';
import useSound from 'use-sound';
import './ChatRoom.css';

import msg from '../../assets/message.wav';
import startSound from '../../assets/button_click.wav';

const socket = io('http://localhost:5000');

const ChatRoom = () => {
  const [username, setUsername] = useState('');
  const [isUsernameSet, setIsUsernameSet] = useState(false);
  const [message, setMessage] = useState('');
  const [chat, setChat] = useState([]);
  const [start] = useSound(startSound);
  const [playSend] = useSound(msg);
  const [playReceive] = useSound(msg);

  const chatEndRef = useRef(null);

  const scrollToBottom = () => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  // Receive messages
  useEffect(() => {
    socket.on('receive_message', (data) => {
      setChat((prev) => [...prev, data]);
      if (data.username !== username) {
        playReceive(); // Sound only for others’ messages
      }
    });

    return () => socket.off('receive_message');
  }, [username]);

  useEffect(() => {
    scrollToBottom();
  }, [chat]);

  // Send messages
  const sendMessage = () => {
    if (message.trim()) {
      const data = {
        username,
        message,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      socket.emit('chatMessage', data);
      setMessage('');
      playSend(); // Play send sound
    }
  };

  if (!isUsernameSet) {
    const handleStartChat = () => {
      if (username) {
        start(); // Play start sound
        setIsUsernameSet(true);
      }
    };
    return (
      <div className="username-bg">
        <div className="chat-container username-screen">
          <h2>👤 Enter your name</h2>
          <input
            type="text"
            placeholder="Your name"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleStartChat()}
          />
          <button onClick={handleStartChat}>Start Chat</button>
        </div>
      </div>
    );
  }

  return (
    <div className="center-screen">
      <div className="chat-container">
        <h2>💬 React Chatroom</h2>
        <div className="chat-box">
          {chat.map((msg, index) => (
            <div
              key={index}
              className={`chat-msg ${msg.username === username ? 'self' : 'other'}`}
            >
              <div className="chat-meta">
                <strong>{msg.username === username ? 'You' : msg.username}</strong> <span>{msg.time}</span>
              </div>
              <div>{msg.message}</div>
            </div>
          ))}
          <div ref={chatEndRef} />
        </div>
        <div className="chat-input">
          <input
            type="text"
            placeholder="Type message..."
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && sendMessage()}
          />
          <button onClick={sendMessage}>Send</button>
        </div>
      </div>
    </div>
  );
};

export default ChatRoom;

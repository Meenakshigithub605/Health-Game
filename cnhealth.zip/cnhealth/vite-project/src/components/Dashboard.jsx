import React from 'react';
import './Dashboard.css';
import { useNavigate } from 'react-router-dom';
import useSound from 'use-sound';
import clickSound from '../assets/button_click.wav'; // Make sure path is correct

const Dashboard = ({ onStartQuiz, onGoToTutorial, onBack }) => {
  const navigate = useNavigate();
  const [playClick] = useSound(clickSound);

  return (
    <div className="dashboard-screen">
      <h1 className="dashboard-title">Welcome to <span className="highlight">Dashboard</span> 💚</h1>
      <div className="dashboard-buttons">
        <button className="dashboard-button" onClick={() => { playClick(); onStartQuiz(); }}>
          Game
        </button>
        <button className="dashboard-button" onClick={() => { playClick(); onGoToTutorial(); }}>
          Tutorial
        </button>
        <button className="dashboard-button" onClick={() => { playClick(); navigate('/chatroom'); }}>
          Open ChatRoom
        </button>
        {/* <button className="dashboard-button" onClick={() => { playClick(); navigate('/about'); }}>
  About
</button> */}

        <button className="dashboard-button back-button" onClick={() => { playClick(); onBack(); }}>
          Back
        </button>
      </div>
    </div>
  );
};

export default Dashboard;

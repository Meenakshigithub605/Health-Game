import React from 'react';
import './Dashboard.css';
import { useNavigate } from 'react-router-dom';

const Dashboard = ({ onStartQuiz, onGoToTutorial, onBack }) => {
  const navigate = useNavigate(); // 🚀 React Router hook

  return (
    <div className="dashboard-screen">
      <h1 className="dashboard-title">Welcome to <span className="highlight">Dashboard</span> 💚</h1>
      <div className="dashboard-buttons">
        <button className="dashboard-button" onClick={onStartQuiz}>Game</button>
        <button className="dashboard-button" onClick={onGoToTutorial}>Tutorial</button>
        <button className="dashboard-button" onClick={() => navigate('/chatroom')}>
          Open ChatRoom
        </button>
        <button className="dashboard-button back-button" onClick={onBack}>Back</button>
      </div>
    </div>
  );
};

export default Dashboard;

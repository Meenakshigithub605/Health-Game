import React from 'react';
import './Tutorial.css';

// Import images statically
import hhImg from '../assets/hh.webp';
import hmImg from '../assets/hm.jpeg';
import pgImg from '../assets/pg.jpeg';
import pcImg from '../assets/pc.jpeg';
import hlImg from '../assets/hl.jpeg';
import lastImg from '../assets/last.png';

const tutorialSteps = [
  {
    title: "Healthy Habits",
    description: "Healthy Habits offers great life....",
    image: hhImg,
    link: "https://youtu.be/vCMNOiQlnD0?si=mWE7wUquOSRrldVn"
  },
  {
    title: "Healthy Meals",
    description: "How to maintain a healthy diet?",
    image: hmImg,
    link: "https://youtu.be/a-084pqI05U?si=QB4a6tueQFOKHQlt"
  },
  {
    title: "Proper Playtime",
    description: "Physical Activities are of same importance as study",
    image: pgImg,
    link: "https://youtu.be/j6cDIH8LkyI?si=iO8TQdklUJC6ptyH"
  },
  {
    title: "Proper Communication",
    description: "Effective Communication is of utmost importance..",
    image: pcImg,
    link: "https://youtu.be/TPhabSkn3sM?si=GAqU2B51TiFET0Dz"
  },
  {
    title: "abcd jkkj fsfs",
    description: "dsgdfh rhdfgj hrdhfdjgf",
    image: hlImg,
    link: "https://youtu.be/kfcvaQS-yuE?si=Z-ACwJLUSHgU_xLL"
  },
  {
    title: "faszsdg dghdf reh",
    description: "sdg dgg dfhdf eh erhh ergg.",
    image: lastImg,
    link: "https://youtu.be/bN36nh-2tuI?si=X6pQj0CYIA2OxS2i"
  }
];

const Tutorial = ({ onBack }) => {
  return (
    <div className="tutorial-container">
      <header className="tutorial-header">
        <h1>Tutorial</h1>
        <p>Welcome to the tutorial! Follow these steps to learn how to use the features of Healthy Minds.</p>
      </header>

      <div className="tutorial-cards">
        {tutorialSteps.map((step, index) => (
          <div className="tutorial-card" key={index}>
            <img src={step.image} alt={`Step ${index + 1}`} className="tutorial-image" />
            <h2>{step.title}</h2>
            <p>{step.description}</p>
            <a href={step.link} target="_blank" rel="noopener noreferrer" className="btn btn-learn-more">Watch Video</a>
          </div>
        ))}
      </div>

      <div className="navigation-buttons">
        <button className="btn btn-back" onClick={onBack}>Back to Dashboard</button>
      </div>
    </div>
  );
};

export default Tutorial;

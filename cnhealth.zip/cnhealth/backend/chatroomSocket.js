module.exports = (io) => {
    io.on("connection", (socket) => {
      console.log("New chatroom client connected");
  
      // Listen for chat messages
      socket.on("chatMessage", (data) => {
        // Ensure message has a valid username
        if (data.username && data.message) {
          // Broadcast message to everyone
          io.emit("receive_message", { username: data.username, message: data.message, time: data.time });
        } else {
          console.log("Message or username missing. Message not broadcasted.");
        }
      });
  
      socket.on("disconnect", () => {
        console.log("Chatroom client disconnected");
      });
    });
  };
  
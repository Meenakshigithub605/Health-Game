// backend/models/GameProgress.js
const mongoose = require('mongoose');

const GameProgressSchema = new mongoose.Schema({
  username: { type: String, required: true },
  score: { type: Number, required: true },
  date: { type: Date, default: Date.now }
});

module.exports = mongoose.model('GameProgress', GameProgressSchema);

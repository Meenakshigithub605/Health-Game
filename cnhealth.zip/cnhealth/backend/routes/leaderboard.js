// backend/routes/leaderboard.js
const express = require('express');
const router = express.Router();
const GameProgress = require('../models/GameProgress');

// Get top scores
router.get('/', async (req, res) => {
  const scores = await GameProgress.find().sort({ score: -1 }).limit(10);
  res.json(scores);
});

// Post a new score
router.post('/', async (req, res) => {
  const { username, score } = req.body;
  const entry = new GameProgress({ username, score });
  await entry.save();
  res.status(201).json({ message: 'Score saved!' });
});

module.exports = router;
